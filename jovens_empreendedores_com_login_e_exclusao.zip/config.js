// Insira os dados PUBLICOS do seu projeto Supabase. NUNCA coloque a service_role key aqui.
window.SITE_CONFIG = {
  supabaseUrl: "COLE_A_URL_DO_SUPABASE",
  supabaseAnonKey: "COLE_A_CHAVE_PUBLICA_ANON_OU_PUBLISHABLE"
};
