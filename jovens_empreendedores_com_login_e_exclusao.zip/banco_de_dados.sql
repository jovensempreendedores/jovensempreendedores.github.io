-- Execute no SQL Editor do Supabase uma única vez.
create table if not exists public.products (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references auth.users(id) on delete cascade,
 name text not null check (char_length(name) between 1 and 70),
 owner text not null check (char_length(owner) between 1 and 60),
 category text not null,
 description text not null check (char_length(description) between 1 and 500),
 price text not null default '',
 contact text not null default '',
 image text not null default '',
 created_at timestamptz not null default now()
);
alter table public.products enable row level security;
drop policy if exists "Anyone can view products" on public.products;
drop policy if exists "Owners can create products" on public.products;
drop policy if exists "Owners can update products" on public.products;
drop policy if exists "Owners can delete products" on public.products;
create policy "Anyone can view products" on public.products for select to anon, authenticated using (true);
create policy "Owners can create products" on public.products for insert to authenticated with check ((select auth.uid()) = user_id);
create policy "Owners can update products" on public.products for update to authenticated using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);
create policy "Owners can delete products" on public.products for delete to authenticated using ((select auth.uid()) = user_id);
